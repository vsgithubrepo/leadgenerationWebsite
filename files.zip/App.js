import { ClerkProvider, SignIn, useUser, useClerk } from '@clerk/clerk-react';
import LeadEngine from './LeadEngine';

const CLERK_KEY     = process.env.REACT_APP_CLERK_PUBLISHABLE_KEY;
const ALLOWED_DOMAIN = process.env.REACT_APP_ALLOWED_DOMAIN || '';
const COMPANY_NAME  = process.env.REACT_APP_COMPANY_NAME || 'Your Company';

// ── Domain Guard ────────────────────────────────────────────────
function DomainGuard({ children }) {
  const { user } = useUser();
  const { signOut } = useClerk();

  if (!user) return null;

  const email = user.primaryEmailAddress?.emailAddress || '';
  const domain = email.split('@')[1] || '';
  const allowed = !ALLOWED_DOMAIN || domain === ALLOWED_DOMAIN;

  if (!allowed) {
    return (
      <div style={styles.blocker}>
        <div style={styles.blockerCard}>
          <div style={styles.blockerIcon}>🔒</div>
          <h2 style={styles.blockerTitle}>Access Restricted</h2>
          <p style={styles.blockerText}>
            LeadEngine is only available to <strong style={{ color: '#f59e0b' }}>@{ALLOWED_DOMAIN}</strong> email addresses.
          </p>
          <p style={styles.blockerSub}>You signed in as <strong>{email}</strong></p>
          <button style={styles.blockerBtn} onClick={() => signOut()}>
            Sign Out & Try Again
          </button>
        </div>
      </div>
    );
  }

  return children;
}

// ── Auth Gate ────────────────────────────────────────────────────
function AuthGate() {
  const { isSignedIn, isLoaded } = useUser();

  if (!isLoaded) {
    return (
      <div style={styles.loading}>
        <div style={styles.loadingDot} />
        <div style={{ ...styles.loadingDot, animationDelay: '0.2s' }} />
        <div style={{ ...styles.loadingDot, animationDelay: '0.4s' }} />
        <style>{`
          @keyframes loadPulse { 0%,100%{opacity:.3;transform:scale(1)} 50%{opacity:1;transform:scale(1.3)} }
        `}</style>
      </div>
    );
  }

  if (!isSignedIn) {
    return (
      <div style={styles.loginPage}>
        {/* Background grid */}
        <div style={styles.loginBg} />

        <div style={styles.loginLeft}>
          <div style={styles.loginBrand}>
            <img src="/logo.svg" alt="eTechCube" style={{ height: 56, width: 'auto', marginBottom: 6 }} />
            <div style={styles.loginTagline}>Lead Generation Platform</div>
          </div>
          <h1 style={styles.loginHeadline}>
            Find 1,000+<br />
            <span style={{ color: '#f59e0b' }}>qualified leads</span><br />
            in minutes.
          </h1>
          <p style={styles.loginDesc}>
            AI-powered B2B lead generation for logistics software sales teams.
            Scrapes JustDial, IndiaMart, LinkedIn & Apollo — completely free.
          </p>
          <div style={styles.loginStats}>
            {[['1,000+', 'Leads per run'], ['4', 'Data sources'], ['₹0', 'Cost per lead']].map(([v, l]) => (
              <div key={l} style={styles.loginStat}>
                <span style={styles.loginStatVal}>{v}</span>
                <span style={styles.loginStatLabel}>{l}</span>
              </div>
            ))}
          </div>
          {ALLOWED_DOMAIN && (
            <div style={styles.loginDomainNote}>
              🔒 Access restricted to <strong>@{ALLOWED_DOMAIN}</strong> accounts
            </div>
          )}
        </div>

        <div style={styles.loginRight}>
          <div style={styles.loginCard}>
            <h2 style={styles.loginCardTitle}>Sign in to LeadEngine</h2>
            <p style={styles.loginCardSub}>Use your {COMPANY_NAME} Google account</p>
            <SignIn
              appearance={{
                elements: {
                  rootBox: { width: '100%' },
                  card: { background: 'transparent', boxShadow: 'none', padding: 0 },
                  headerTitle: { display: 'none' },
                  headerSubtitle: { display: 'none' },
                  socialButtonsBlockButton: {
                    background: '#1e2530',
                    border: '1px solid rgba(255,255,255,0.12)',
                    color: '#e8e4dc',
                    borderRadius: '10px',
                    padding: '13px',
                    fontSize: '14px',
                    fontWeight: '500',
                  },
                  dividerLine: { background: 'rgba(255,255,255,0.08)' },
                  dividerText: { color: '#6b7280' },
                  formFieldInput: {
                    background: '#1e2530',
                    border: '1px solid rgba(255,255,255,0.12)',
                    color: '#e8e4dc',
                    borderRadius: '8px',
                  },
                  formButtonPrimary: {
                    background: 'linear-gradient(135deg,#f59e0b,#d97706)',
                    color: '#0a0c0f',
                    fontWeight: '700',
                    borderRadius: '8px',
                    border: 'none',
                  },
                  footerActionLink: { color: '#f59e0b' },
                  identityPreviewText: { color: '#e8e4dc' },
                  formFieldLabel: { color: '#9ca3af' },
                },
                variables: {
                  colorBackground: '#111418',
                  colorText: '#e8e4dc',
                  colorPrimary: '#f59e0b',
                  borderRadius: '10px',
                },
              }}
              redirectUrl="/"
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <DomainGuard>
      <LeadEngine />
    </DomainGuard>
  );
}

// ── Root ────────────────────────────────────────────────────────
export default function App() {
  if (!CLERK_KEY) {
    return (
      <div style={styles.noKey}>
        <div style={styles.noKeyCard}>
          <div style={{ fontSize: 40, marginBottom: 16 }}>⚙️</div>
          <h2 style={{ fontFamily: 'Syne, sans-serif', marginBottom: 8 }}>Setup Required</h2>
          <p style={{ color: '#9ca3af', fontSize: 14, marginBottom: 16 }}>
            Add your Clerk Publishable Key to <code style={{ background: '#1e2530', padding: '2px 6px', borderRadius: 4 }}>.env.local</code>
          </p>
          <code style={styles.noKeyCode}>REACT_APP_CLERK_PUBLISHABLE_KEY=pk_test_...</code>
          <p style={{ color: '#6b7280', fontSize: 12, marginTop: 12 }}>
            Get your free key at <strong style={{ color: '#f59e0b' }}>clerk.com</strong>
          </p>
        </div>
      </div>
    );
  }

  return (
    <ClerkProvider publishableKey={CLERK_KEY}>
      <AuthGate />
    </ClerkProvider>
  );
}

// ── Styles ───────────────────────────────────────────────────────
const styles = {
  loading: { display: 'flex', gap: 10, justifyContent: 'center', alignItems: 'center', height: '100vh', background: '#0a0c0f' },
  loadingDot: { width: 10, height: 10, borderRadius: '50%', background: '#f59e0b', animation: 'loadPulse 1.2s ease-in-out infinite' },

  loginPage: { display: 'flex', minHeight: '100vh', background: '#0a0c0f', fontFamily: "'DM Sans', sans-serif", position: 'relative', overflow: 'hidden' },
  loginBg: { position: 'absolute', inset: 0, backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(245,158,11,0.05) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(245,158,11,0.03) 0%, transparent 40%)', pointerEvents: 'none' },

  loginLeft: { flex: 1, padding: '60px 64px', display: 'flex', flexDirection: 'column', justifyContent: 'center', maxWidth: 560, position: 'relative', zIndex: 1 },
  loginBrand: { marginBottom: 48 },
  loginLogo: { fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 22, color: '#f59e0b', lineHeight: 1.1, letterSpacing: '-0.5px' },
  loginTagline: { fontSize: 10, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.12em', marginTop: 4 },
  loginHeadline: { fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 48, lineHeight: 1.1, letterSpacing: '-2px', color: '#e8e4dc', marginBottom: 20 },
  loginDesc: { color: '#9ca3af', fontSize: 15, lineHeight: 1.7, marginBottom: 40, maxWidth: 420 },
  loginStats: { display: 'flex', gap: 32, marginBottom: 32 },
  loginStat: { display: 'flex', flexDirection: 'column', gap: 2 },
  loginStatVal: { fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 26, color: '#f59e0b' },
  loginStatLabel: { fontSize: 11, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.08em' },
  loginDomainNote: { fontSize: 12, color: '#6b7280', padding: '10px 14px', background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.15)', borderRadius: 8 },

  loginRight: { width: 440, background: '#0d1117', borderLeft: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px', position: 'relative', zIndex: 1 },
  loginCard: { width: '100%', maxWidth: 360 },
  loginCardTitle: { fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 22, color: '#e8e4dc', marginBottom: 6 },
  loginCardSub: { color: '#6b7280', fontSize: 13, marginBottom: 28 },

  blocker: { display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#0a0c0f' },
  blockerCard: { background: '#111418', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 16, padding: '48px 40px', textAlign: 'center', maxWidth: 400 },
  blockerIcon: { fontSize: 48, marginBottom: 16 },
  blockerTitle: { fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 22, color: '#e8e4dc', marginBottom: 12 },
  blockerText: { color: '#9ca3af', fontSize: 14, lineHeight: 1.6, marginBottom: 8 },
  blockerSub: { color: '#6b7280', fontSize: 13, marginBottom: 24 },
  blockerBtn: { padding: '11px 24px', borderRadius: 8, border: 'none', background: '#1e2530', color: '#e8e4dc', fontWeight: 600, fontSize: 13, cursor: 'pointer' },

  noKey: { display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#0a0c0f' },
  noKeyCard: { background: '#111418', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 16, padding: '48px 40px', textAlign: 'center', maxWidth: 440, color: '#e8e4dc' },
  noKeyCode: { display: 'block', background: '#1e2530', padding: '10px 16px', borderRadius: 8, fontSize: 12, color: '#f59e0b', fontFamily: 'monospace', border: '1px solid rgba(245,158,11,0.2)' },
};
